console.log('[🔍 content-script.js] Running...');

let timesheetUserId = null;
let csrfToken = null;

function isOnTimesheetPage() {
  const url = new URL(window.location.href);

  const isCorrectPath = url.pathname.startsWith("/employees/timesheet/");
  const idParam = url.searchParams.get("id");

  if (idParam && /^\d+$/.test(idParam)) {
    timesheetUserId = idParam;
  }

  return isCorrectPath && timesheetUserId !== null;
}


function addFillButton() {
    const controlsContainer = document.querySelector("div.TimesheetHeader__controls");
    if (!controlsContainer) return;
  
    if (controlsContainer.querySelector("#myFillButton")) return;
  
    const button = document.createElement("button");
    button.id = "myFillButton";
    button.textContent = "FILL";
    
    button.style.marginRight = "8px";
    button.style.padding = "8px 16px";
    button.style.backgroundColor = "#007BFF"; 
    button.style.color = "#fff";
    button.style.border = "none";
    button.style.borderRadius = "6px";
    button.style.cursor = "pointer";
    button.style.fontWeight = "bold";
    button.style.fontSize = "14px";
    button.style.boxShadow = "0 2px 6px rgba(0, 0, 0, 0.15)";
    button.style.transition = "background-color 0.3s ease";
    
    button.addEventListener("mouseover", () => {
      button.style.backgroundColor = "#0056b3";
    });
    button.addEventListener("mouseout", () => {
      button.style.backgroundColor = "#007BFF";
    });
  
    button.addEventListener("click", () => {
        if (!timesheetUserId) {
          console.error("User ID is missing");
          return;
        }
      
        const url1 = `https://wizeline.bamboohr.com/employees/timesheet/?id=${timesheetUserId}`;
        console.log("Fetching metadata from:", url1);
      
        fetch(url1, { credentials: "include" })
          .then(res => res.text())
          .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, "text/html");

            const scriptText = Array.from(doc.scripts).map(s => s.textContent).join("\n");
            const csrfMatch = scriptText.match(/var\s+CSRF_TOKEN\s*=\s*"([^"]+)"/);
            csrfToken = csrfMatch ? csrfMatch[1] : null;

            if (!csrfToken) {
            console.error("❌ CSRF_TOKEN not found in page HTML");
            return;
            }

            console.log("✅ CSRF_TOKEN:", csrfToken);

            const scriptTag = doc.querySelector("#js-timesheet-data");
      
            if (!scriptTag) throw new Error("JSON script not found");
      
            const jsonData = JSON.parse(scriptTag.textContent);
            const currentTimesheetId = jsonData.currentTimesheetId;
      
            console.log("📌 Current timesheet ID:", currentTimesheetId);
      
            // Now fetch the actual timesheet data
            const url2 = `https://wizeline.bamboohr.com/timesheet/${currentTimesheetId}`;
            return fetch(url2, { credentials: "include" }).then(res => res.json());
          })
          .then(timesheetData => {
          
            const dailyDetails = timesheetData.timesheet.dailyDetails;
            const employeeId = timesheetData.timesheet.employeeId || timesheetData.employeeId || 1799;
          
            
            const approvableDate = new Date(timesheetData.timesheet.approvableDate * 1000);
            const approvableMonth = approvableDate.getMonth() + 1;
            //const isSummerTime = approvableMonth >= 6 && approvableMonth <= 8;
            const isSummerTime = false;
            
            const entriesToPost = [];
            const entriesToDelete = [];
          
            for (const date in dailyDetails) {
              const details = dailyDetails[date];
              const day = new Date(date).getDay(); // 0 = Sunday, 6 = Saturday
          
              const isWeekday = day >= 1 && day <= 5;
              const isEligible = isWeekday && details.timeOff.length === 0 && details.holidays.length === 0;
          
              if (isEligible) {
                // Collect existing clockEntry IDs (for deletion)
                if (details.clockEntries && details.clockEntries.length > 0) {
                  details.clockEntries.forEach(entry => {
                    if (entry && entry.id) {
                      entriesToDelete.push(entry.id);
                    }
                  });
                }

                
                  entriesToPost.push({
                    id: null,
                    trackingId: null,
                    employeeId,
                    date,
                    start: "09:00",
                    end: "13:00",
                    note: "",
                    projectId: null,
                    taskId: null
                  });

                  if (day<5){
                    entriesToPost.push({
                      id: null,
                      trackingId: null,
                      employeeId,
                      date,
                      start: isSummerTime? "13:15": "14:00",
                      end: isSummerTime ? "16:15" : "18:30",
                      note: "",
                      projectId: null,
                      taskId: null
                    });    
                  }
                  else{
                    entriesToPost.push({
                      id: null,
                      trackingId: null,
                      employeeId,
                      date,
                      start: "13:15",
                      end: "15:15",
                      note: "",
                      projectId: null,
                      taskId: null
                    });
                  }
                  
                

          
                
              }
            }
          
            const deletePromise = entriesToDelete.length > 0
              ? fetch("https://wizeline.bamboohr.com/timesheet/clock/entries", {
                  method: "DELETE",
                  headers: {
                    "Content-Type": "application/json",
                    "x-csrf-token": csrfToken
                  },
                  credentials: "include",
                  body: JSON.stringify({ entries: entriesToDelete })
                }).then(res => res.text())
              : Promise.resolve("No entries to delete");
          
            deletePromise.then(() => {
              if (entriesToPost.length > 0) {
                fetch("https://wizeline.bamboohr.com/timesheet/clock/entries", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    "x-csrf-token": csrfToken
                  },
                  credentials: "include",
                  body: JSON.stringify({ entries: entriesToPost })
                })
                  .then(res => res.text())
                  .then(result => {
                    alert("Timesheet filled successfully. Please refresh the page to see the updates.");
                  })
                  .catch(err => console.error("Error posting entries:", err));
              } else {
                console.log("No eligible entries to post");
              }
            }).catch(err => {
              console.error("Error deleting old entries:", err);
            });
          });
  
  });
  controlsContainer.insertBefore(button, controlsContainer.firstChild);

}

window.addEventListener("load", () => {
    if (!isOnTimesheetPage()) return;

    const observer = new MutationObserver(() => {
        const found = document.querySelector("div.TimesheetHeader__controls");
        if (found) {
        addFillButton();
        observer.disconnect();
        }
});

observer.observe(document.body, { childList: true, subtree: true });
    addFillButton();
});